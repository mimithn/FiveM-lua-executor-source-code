# FIVEM External Cheat

## Best Undetected cheat for FIVEM with 100+ features and BUILT IN SPOOFER

## Password to extract files: icgo

## How to use? 

1. Download this repository by clicking on CODE > DOWNLOAD ZIP

2. Open .zip file that you downloaded from this repository and extract everything to Desktop. 

3. Open IcgoClient.exe

4. Open FIVEM and software will automatically bypass AC and run the cheat.

5. In game, press F11 or INSERT to open Main Menu.

# Features: 

# Aimbot:

– FOV

– Show FOV

– Bone

– Aim at Players

– Aim at NPCs

– Aim Crosshair/Distance

– Smooth Aim

– No Spread

– No Recoil

– Instant Reload

– Unlimited Ammo

– 1 Hit Kill

– Heavy Bullets

– Projectiles Per Shot

– Smooth Aim

# ESP:

– Players

– Names

– Skeletons

– Lasers

– Health

– NPCs

– 2D Boxes

– 3D Boxes

# Miscellaneous:

– Never Wanted

– Increase Wanted

– Decrease Wanted

– God Mode

– Vehicle God Mode

– Superjump

– Explosive Bullets

– Fire Bullets

– Explosive Melee

– No Ragdoll

– Unlimited Stamina

– Unlimited Fuel

- Lua Executor

- Dumper

- Money cheat (undetected)

## Preview:

![xcsd](https://user-images.githubusercontent.com/113134426/189218655-2a2ebabf-a28f-469d-a9dd-2cc3c0ae5e2c.png)
![xcsd](https://user-images.githubusercontent.com/113134426/189218786-7a8c2365-bf9f-423f-9cb5-e12829cf73be.png)
![xcsd](https://user-images.githubusercontent.com/113134426/189218919-0cdfaed3-e660-4cef-8421-007deef1ea07.png)
![xcsd](https://user-images.githubusercontent.com/113134426/189219006-4b6b6fb4-dabc-4d4e-a7d2-e3ab72c5d677.png)
